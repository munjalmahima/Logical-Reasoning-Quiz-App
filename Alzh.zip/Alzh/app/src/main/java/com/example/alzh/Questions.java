package com.example.alzh;
class Questions {
    public String questions[] = {
            "7*10+5*10+2",
            "(5*5+5*6)*0*4*6*9+4",
            "If Sheila is the wife of my father and i am your brother,then what is your relation with Sheila."
    };

    public String choices[][] = {
            {"172", "152", "1260", "122"},
            {"0", "25", "4", "55"},
            {"Sister", "Brother", "Father", "Son"}
    };

    public String correctAnswer[] = {
            "122",
            "4",
            "Son"
    };

    public String getQuestion(int a){
        String question = questions[a];
        return question;
    }

    public String getchoice1(int a){
        String choice = choices[a][0];
        return choice;
    }

    public String getchoice2(int a){
        String choice = choices[a][1];
        return choice;
    }

    public String getchoice3(int a){
        String choice = choices[a][2];
        return choice;
    }

    public String getchoice4(int a){
        String choice = choices[a][3];
        return choice;
    }

    public String getCorrectAnswer(int a){
        String answer = correctAnswer[a];
        return answer;
    }
}
